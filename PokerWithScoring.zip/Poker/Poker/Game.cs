﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poker
{
    /// <summary>
    /// Authored By Todd T.
    /// </summary>
    class Game
    {
        public Player[] Players { get; private set; }
        public Deck gameDeck { get; }
        
        /// <summary>
        /// Constructor
        /// Comment out the foreach if you need to print something to the screen for testing
        /// </summary>
        public Game()
        {
            gameDeck = new Deck();
            InitPlayers();
            DealHands();

            Table.DrawTable();
            foreach (var player in Players)
            {
                Console.WriteLine(player);
                SortHand(player.Hand);
                Console.WriteLine(ScoreHand(player.Hand));
                Console.WriteLine("------------");
            }
        }

        /// <summary>
        /// Takes a given collection of cards and assigns a score based on the tradition ranking system.
        /// See interior comments for more info
        /// </summary>
        /// <param name="hand">Set of cards to be evaluated. Expected to be sorted in descending value of rank.</param>
        /// <returns>Decimal Value</returns>
        public double ScoreHand(List<Card> hand)
        {
            //Var used to add high card to hands upon return
            //The decimal value for the sake of clarity for testing and not interferring in low scoring hands
            double highCard = hand[0].Value * .01;

            //FLUSH
            if (hand.GroupBy(c => c.Suit).Count() == 1) //Checks if cards grouped by suit form a single group
            {
                //STRAIGHT FLUSH
                if (hand.GroupBy(c => c.Value).Count(group => group.Count() > 1) == 0 && hand[0].Value - hand[4].Value == 4) //See comment for straight
                {
                    //ROYAL FLUSH
                    if (hand[0].Value == 14) //After all other checks, checking for an Ace at the front is all that's needed for a royal flush check
                    {
                        return 1000;
                    }
                    return 900 + highCard;
                }
                return 600 + highCard; //This return is out of sequence, but having a flush with any kind of pairing hand is impossible
            }


            //IGrouping variable used to check for occurences of the same value for their respective hands, including once for a straight
            var dupCheck = hand.GroupBy(card => card.Value).OrderByDescending(group => group.Count()).ThenByDescending(group => group.ElementAt(0).Value);

            /*FOUR OF A KIND
             * Finding multiples requires a bit of sifting, but the process is pretty simple
             */
            if (dupCheck.ElementAt(0).Count() == 4)
            {               
                int fourOfAKindHigh = dupCheck.ElementAt(0).ElementAt(0).Value;
                return 800 + highCard;
            }

            //FULL HOUSE
            if(dupCheck.ElementAt(0).Count() == 3 && dupCheck.ElementAt(1).Count() == 2)
            {
                int FullHouseHigh = dupCheck.ElementAt(0).ElementAt(0).Value;
                return 700 + FullHouseHigh;
            }


            /*STRAIGHT
             *Checks for any value groups with a count higher than one 
             *then checks if the difference between the highest card and lowest card is 4 indicating a sequence.
             *This step requires cards to be ordered upon being passed in, for clarity rather than logic 
             */
            if (dupCheck.Count(group => group.Count() > 1) == 0 && hand[0].Value - hand[4].Value == 4)
            {
                return 500 + highCard;
            }

            //THREE OF A KIND
            //Due to the more complex ranking required in non 
            if (dupCheck.ElementAt(0).Count() == 3)
            {
                int threeKindValue = dupCheck.ElementAt(0).ElementAt(0).Value 
                    + 400;
                return threeKindValue + highCard;
            }

            //TWO PAIR
            if (dupCheck.ElementAt(0).Count() == 2 && dupCheck.ElementAt(1).Count() == 2)
            {
                int twoPairValue = 
                    dupCheck.ElementAt(0).ElementAt(0).Value
                    + dupCheck.ElementAt(1).ElementAt(0).Value
                    + 100;
                return twoPairValue + highCard;
            }

            //ONE PAIR
            if (dupCheck.ElementAt(0).Count() == 2)
            {
                int pairValue = dupCheck.ElementAt(0).ElementAt(0).Value;
                return pairValue + highCard;
            }

            //HIGH CARD
            return highCard;
        }

        /// <summary>
        /// Sorts hand value in place in descending order
        /// </summary>
        /// <param name="hand">Unformatted list of cards</param>
        private void SortHand(List<Card> hand)
        {
            hand.Sort((x, y) => y.Value.CompareTo(x.Value));
            Table.PrintCardsHori(hand);
        }

        /// <summary>
        /// Creates the human player and AI players
        /// For use specifically in constructor
        /// </summary>
        private void InitPlayers()
        {
            Players = new Player[4];
            Players[0] = new Player(500, true);

            for (int i = 1; i < Players.Length; i++)
            {
                Players[i] = new Player(500, false);
            }
        }

        /// <summary>
        /// Fills the hands of all players with 5 cards taken from the deck
        /// </summary>
        private void DealHands()
        {
            foreach (Player p in Players)
            {
                for (int i = 0; i < 5; i++)
                    p.Hand.Add(gameDeck.DrawCard());
            }
        }


    }
}
