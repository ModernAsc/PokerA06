﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poker
{
    static class Table
    {
        public static void PrintCardsHori(IList<Card> hand)
        {
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;
            Console.Write("|");
            foreach(Card c in hand)
            {
                Console.Write(c);
                Console.ForegroundColor = ConsoleColor.Black;
                Console.Write("|");
            }
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.Green;
            Console.WriteLine();
        }

        public static void DrawTable()
        {
            Console.BackgroundColor = ConsoleColor.Green;
            String fill = new string(' ', Console.BufferWidth - 1);
            for (int  i = 0;  i < Console.BufferHeight;  i++)
            {
                Console.WriteLine(fill);
            }
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(0, 0);
        }
    }
}
